cd hahn-client-app
npm run dev